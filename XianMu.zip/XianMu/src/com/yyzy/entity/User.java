package com.yyzy.entity;

import java.util.Date;

public class User {
    private Integer uId;

    private String userId;

    private String userName;

    private String userPass;

    private String userSex;

    private String userShengfengzheng;

    private Date userDate;

    private Integer postId;
    
    private Post post;

    private String userPhone;

    private String userEmail;

    private String userDizhi;

    private String userType;

    private String userMiaoshu;

    public Integer getuId() {
        return uId;
    }

    public void setuId(Integer uId) {
        this.uId = uId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId == null ? null : userId.trim();
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass == null ? null : userPass.trim();
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex == null ? null : userSex.trim();
    }

    public String getUserShengfengzheng() {
        return userShengfengzheng;
    }

    public void setUserShengfengzheng(String userShengfengzheng) {
        this.userShengfengzheng = userShengfengzheng == null ? null : userShengfengzheng.trim();
    }

    public Date getUserDate() {
        return userDate;
    }

    public void setUserDate(Date userDate) {
        this.userDate = userDate;
    }

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    
    public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}

	public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone == null ? null : userPhone.trim();
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail == null ? null : userEmail.trim();
    }

    public String getUserDizhi() {
        return userDizhi;
    }

    public void setUserDizhi(String userDizhi) {
        this.userDizhi = userDizhi == null ? null : userDizhi.trim();
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType == null ? null : userType.trim();
    }

    public String getUserMiaoshu() {
        return userMiaoshu;
    }

    public void setUserMiaoshu(String userMiaoshu) {
        this.userMiaoshu = userMiaoshu == null ? null : userMiaoshu.trim();
    }
}