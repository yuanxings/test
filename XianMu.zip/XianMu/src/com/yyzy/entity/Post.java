package com.yyzy.entity;

public class Post {
    private Integer postId;

    private String postName;

    private String postYouxian;

    public Integer getPostId() {
        return postId;
    }

    public void setPostId(Integer postId) {
        this.postId = postId;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName == null ? null : postName.trim();
    }

    public String getPostYouxian() {
        return postYouxian;
    }

    public void setPostYouxian(String postYouxian) {
        this.postYouxian = postYouxian == null ? null : postYouxian.trim();
    }
}