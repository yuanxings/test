package com.yyzy.dao;

import org.apache.ibatis.annotations.Param;

import com.yyzy.entity.User;

public interface UserMapper {
	User querUser(@Param("names") String name,@Param("password") String password);
	
    int deleteByPrimaryKey(Integer uId);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(Integer uId);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
}