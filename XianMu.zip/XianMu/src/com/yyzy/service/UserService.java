package com.yyzy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.yyzy.dao.UserMapper;
import com.yyzy.entity.User;

@Service
public class UserService {
	@Autowired
	private UserMapper userMapper;
	
	//��¼��֤
	public User loginUser(String name,String password){
		
		User user=userMapper.querUser(name, password);
		
		return user;
	}
}
