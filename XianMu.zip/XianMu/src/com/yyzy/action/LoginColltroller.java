package com.yyzy.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.yyzy.entity.User;
import com.yyzy.service.UserService;

@Controller
@RequestMapping(value="/")
public class LoginColltroller {
	@Autowired
	private UserService userService;
	@RequestMapping(value="/login")
	public String verifyUser(@RequestParam("name") String name,
			@RequestParam("password") String password,
			@RequestParam("verify") String verify,
			HttpServletRequest request,HttpSession session){
		String sessionCode = (String) session.getAttribute("safecode");
		if (sessionCode.equals(verify)) {
			User user=userService.loginUser(name, password);
			System.out.println(user.getPost().getPostYouxian());
			if ( user!= null) {
				session.setAttribute("users", user);
				System.out.println();
				return "index.jsp";
			}else {
				request.setAttribute("msg", "<script type='text/javascript'>alert('�˺Ż�����������������룡');</script>");
				return "login.jsp";
			}
		}else{
			request.setAttribute("msg", "<script type='text/javascript'>alert('��֤�����');</script>");
			return "login.jsp";
		}
		
	}
}
