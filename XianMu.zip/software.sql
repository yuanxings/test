/*
Navicat MySQL Data Transfer

Source Server         : Java
Source Server Version : 50528
Source Host           : 127.0.0.1:3306
Source Database       : software

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2019-05-23 12:18:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for compensation
-- ----------------------------
DROP TABLE IF EXISTS `compensation`;
CREATE TABLE `compensation` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_zhanghu` varchar(255) DEFAULT NULL,
  `c_yinghang` varchar(255) DEFAULT NULL,
  `c_bonus` float DEFAULT NULL,
  `c_jibengbonus` float DEFAULT NULL,
  `c_qita` float DEFAULT NULL,
  `c_date` date DEFAULT NULL,
  `c_miaosu` varchar(255) DEFAULT NULL,
  `u_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`c_id`),
  KEY `u_id` (`u_id`),
  CONSTRAINT `compensation_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `user` (`u_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of compensation
-- ----------------------------
INSERT INTO `compensation` VALUES ('1', '123456484545', '农业银行', '300', '3500', '200', '2019-05-23', '新录用的员工', '2');

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_name` varchar(255) DEFAULT NULL,
  `post_youxian` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES ('1', '程序员', '低级');
INSERT INTO `post` VALUES ('2', '经理', '高级');
INSERT INTO `post` VALUES ('3', '总经理', '顶级');
INSERT INTO `post` VALUES ('4', '财务', '中级');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  `user_sex` varchar(255) DEFAULT NULL,
  `user_shengfengzheng` varchar(20) DEFAULT NULL,
  `user_date` date DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_dizhi` varchar(255) DEFAULT NULL,
  `user_type` varchar(255) DEFAULT NULL,
  `user_miaoshu` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`u_id`),
  KEY `post_id` (`post_id`),
  KEY `u_id` (`u_id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'abc', '益华', '123456', '男', '1212121212121212', '2019-05-23', '1', '111212111', '123@.com121', '湖南长沙岳麓区', '正式员工', '真正的员工');
INSERT INTO `user` VALUES ('2', 'admin', '袁兴', '123456', '男', '430524199905011812', '2019-05-23', '3', '18773041976', '1263087440qq.@com', '湖南邵阳隆回县', '正式员工', '真正的员工');
